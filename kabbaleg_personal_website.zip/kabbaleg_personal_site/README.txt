KABBALEG.COM — PERSONAL WEBSITE STARTER

INCLUDED
- index.html: responsive personal homepage, blog cards, about and contact sections
- article.html: sample blog article layout
- login.html: member login design preview
- admin.html: admin dashboard design preview
- styles.css / portal.css: responsive styling
- script.js: mobile navigation and contact email handoff

IMPORTANT SECURITY NOTES
This package is a static front-end starter. The login and admin pages are only visual previews:
they are not protected, do not authenticate users, and must not be used for real accounts or private data.
The contact form opens the visitor's email app; it does not store messages on a server.
For production accounts/admin/blog publishing, add a secure backend or managed service with authentication,
database storage, server-side authorization, spam protection, and HTTPS.

BEFORE PUBLISHING
1. Open script.js and replace CONTACT_EMAIL with your real email address.
2. Replace sample bio text and sample blog content with your own.
3. Preview index.html in a browser.
4. Buy/confirm the domain kabbaleg.com and a hosting plan.
5. Upload all files/folders to your host's public web root (often public_html).
6. Set the domain DNS records as instructed by your hosting provider and enable HTTPS/SSL.
7. Test on a phone and desktop. Verify links and the contact email.

For a real CMS with accounts and admin access, use a managed platform such as WordPress hosting,
or build a backend with a trusted authentication provider. Never store passwords in front-end JavaScript.
